#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Employee.h"
#include "Controller.h"
#include "Input.h"
#include "parser.h"


/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee)
{
    FILE* pArchivo;
    int retorno = -1;
    int estado = 0;
    pArchivo = fopen(path,"r");

    if(pArchivo != NULL)
    {
        estado = ll_isEmpty(pArrayListEmployee);

        if(estado == 1)
        {
            retorno = parser_EmployeeFromText(pArchivo,pArrayListEmployee);

        }
        else
        {
            retorno = 2;
        }
    }
    return retorno;
}

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee)
{
    FILE* pArchivo;
    int retorno = -1;
    int estado = 0;

    pArchivo = fopen(path,"rb");

    if(pArchivo != NULL && pArrayListEmployee != NULL)
    {
        estado = ll_isEmpty(pArrayListEmployee);

        if(estado == 1)
        {
            retorno = parser_EmployeeFromBinary(pArchivo,pArrayListEmployee);
        }
        else
        {
            retorno = 2;
        }
    }

    return retorno;
}

/** \brief Alta de empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee)
{
    int id;
    char nombre[51];
    int horasTrabajadas;
    int sueldo;
    int respuesta;

    int retorno = -1;

    Employee* unEmpleado = employee_new();

    if(pArrayListEmployee!=NULL)
    {
        id = controller_getMaxID(pArrayListEmployee);
        id++;
        employee_setId(unEmpleado,id);
        getString("Ingresar nombre para empleado: ",nombre,"Error al ingresar nombre de empleado.");
        employee_setNombre(unEmpleado,nombre);
        horasTrabajadas = getInt("Ingresar cantidad de horas trabajadas: ");
        employee_setHorasTrabajadas(unEmpleado,horasTrabajadas);
        sueldo = getInt("Ingresar sueldo: ");
        employee_setSueldo(unEmpleado,sueldo);

        respuesta = getChar("Confirmar carga de empleado? S/N");

        if(respuesta == 's' || respuesta == 'S')
        {
            ll_add(pArrayListEmployee,unEmpleado);
            retorno = 1;
        }
    }

    return retorno;
}

/** \brief Modificar datos de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee)
{
    Employee* unEmpleado = NULL;
    Employee* auxEmpleado;

    int retorno = -1;
    int flag = 0;
    int respuesta;
    int opcion;

    int id;
    char nombre[51];
    int horasTrabajadas;
    int sueldo;

    char auxID[] = "ID";
    char auxNombre[] = "NOMBRE";
    char auxHrsTra[] = "HRS.TRABAJADAS";
    char auxSueldo[] = "SUELDO";

    if(pArrayListEmployee != NULL)
    {
        controller_ListEmployee(pArrayListEmployee);

        id = getInt("\nIngrese el ID del empleado que desea modificar: ");
        unEmpleado = (Employee*)controller_getEmpleadoPorId(pArrayListEmployee,id);

        if(unEmpleado!=NULL)
        {
            system("cls");

            printf("Se encontro el siguiente empleado: \n\n");
            printf("%4s%20s%18s%10s\n",auxID,auxNombre,auxHrsTra,auxSueldo);
            mostrarEmpleado(unEmpleado);

            auxEmpleado = unEmpleado;
            do
            {
                opcion = getInt("\n\nQue desea modificar?\n1-Nombre\n2-Hrs. Trabajadas\n3-Sueldo.\n4-Vista previa\n\n");

                switch(opcion)
                {
                    case 1:
                        system("cls");
                        getString("Ingrese el nuevo nombre: ",nombre,"Error al modificar nombre!");
                        employee_setNombre(auxEmpleado,nombre);
                        flag = 1;
                        break;

                    case 2:
                        system("cls");
                        horasTrabajadas = getInt("Ingrese la cantidad de hrs. trabajadas: ");
                        employee_setHorasTrabajadas(auxEmpleado,horasTrabajadas);
                        flag = 1;
                        break;

                    case 3:
                        system("cls");
                        sueldo=getInt("Ingrese el nuevo sueldo: ");
                        employee_setSueldo(auxEmpleado,sueldo);
                        flag = 1;
                        break;

                    case 4:
                        break;

                    default:
                        system("cls");
                        printf("Opcion invalida! Reingrese una opcion valida!\n\n");
                }
            }while(opcion!=4);

            if(flag == 1)
            {
                system("cls");
                printf("Con las modificaciones el empleado quedara de la siguiente manera: \n\n");
                mostrarEmpleado(auxEmpleado);

                respuesta = getChar("\n\nDesea confirmar los cambios? S/N\n");

                if(respuesta == 's' || respuesta == 'S')
                {
                    unEmpleado = auxEmpleado;

                    retorno = 1;
                }
                else
                {
                    system("cls");
                    printf("\n\nSe ha cancelado la modificacion!\n\n");
                    retorno = 2;
                }
            }
            else
            {
                retorno = 3;
            }
        }
    }
    return retorno;
}

/** \brief Baja de empleado
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee)
{
    int retorno;
    int respuesta;

    Employee* unEmpleado;
    int id;
    int indexEmpleado;

    if(pArrayListEmployee != NULL)
    {
        controller_ListEmployee(pArrayListEmployee);
        id = getInt("\n\nIngresar ID del empleado que desea dar de baja: ");

        unEmpleado = (Employee*) controller_getEmpleadoPorId(pArrayListEmployee,id);

        if(unEmpleado != NULL)
        {
            mostrarEmpleado(unEmpleado);

            respuesta = getChar("\n\nDesea confirmar la baja de este empleado? S/N\n\n");

            if(respuesta == 's' || respuesta == 'S')
            {

                /*ll_remove(pArrayListEmployee,id);
                system("cls");
                printf("\nBaja realizada con exito!\n\n");
                retorno = 1;
                */
                system("cls");
                indexEmpleado = ll_indexOf(pArrayListEmployee, unEmpleado);
                retorno = ll_remove(pArrayListEmployee, indexEmpleado);
                printf("\nBaja realizada con exito!\n\n");
                retorno = 1;
            }
            else
            {
                system("cls");
                printf("Baja cancelada!\n\n");
                retorno = -1;

            }
        }
    }

    return retorno;
}

/** \brief Listar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee)
{
    int retorno = -1;
    int i;
    int len;

    char auxID[] = "ID";
    char auxNombre[] = "NOMBRE";
    char auxHrsTra[] = "HRS.TRABAJADAS";
    char auxSueldo[] = "SUELDO";

    Employee* unEmpleado = NULL;

    if(pArrayListEmployee != NULL)
    {
        len = ll_len(pArrayListEmployee);

        printf("%4s%20s%18s%10s\n",auxID,auxNombre,auxHrsTra,auxSueldo);

        for(i=0; i<len; i++)
        {
            unEmpleado = (Employee*)ll_get(pArrayListEmployee,i);

            mostrarEmpleado(unEmpleado);
        }

        retorno = 1;
    }

    return retorno;
}

/** \brief Ordenar empleados
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */

int controller_sortEmployee(LinkedList* pArrayListEmployee)
{
    int retorno = -1;
    int opcion;
    int tipo;

    if(pArrayListEmployee != NULL)
    {
            opcion = getInt("Que tipo de ordenamiento desea?\n1-Por nombre\n2-Por ID\n3-Por hrs. trabajadas\n4-Por sueldo.\n5-Salir\n\n");

            switch(opcion)
            {

                case 1:
                    system("cls");
                    tipo = getInt("Se ordenara por nombre.\nSi desea ordenar descendentemente ingrese 1\nSi desea ordenar ascendentemente ingrese 2\n\n");
                    ll_sort(pArrayListEmployee,compararPorNombre,tipo-1);
                    printf("Se ha modificado el orden segun los criterios solicitados");
                    break;

                case 2:
                    system("cls");
                    tipo = getInt("Se ordenara por ID.\nSi desea ordenar descendentemente ingrese 1\nSi desea ordenar ascendentemente ingrese 2\n\n");
                    ll_sort(pArrayListEmployee,compararPorLegajo,tipo-1);
                    printf("Se ha modificado el orden segun los criterios solicitados");
                    break;

                case 3:
                    system("cls");
                    tipo = getInt("Se ordenara por hrs. trabajadas.\nSi desea ordenar descendentemente ingrese 1\nSi desea ordenar ascendentemente ingrese 2\n\n");
                    ll_sort(pArrayListEmployee,compararPorHorasTrabajadas,tipo-1);
                    printf("Se ha modificado el orden segun los criterios solicitados");
                    break;

                case 4:
                    system("cls");
                    tipo = getInt("Se ordenara por sueldo.\nSi desea ordenar descendentemente ingrese 1\nSi desea ordenar ascendentemente ingrese 2\n\n");
                    ll_sort(pArrayListEmployee,compararPorSueldo,tipo-1);
                    printf("Se ha modificado el orden segun los criterios solicitados");
                    break;

                case 5:
                    break;

                default:
                    printf("\nOpcion invalida\n");
            }

        retorno = 1;
    }

    return retorno;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListEmployee)
{
    int retorno = -1;

    FILE* pArchivo;
    Employee* unEmpleado;

    int id;
    char nombre[50];
    int sueldo;
    int horasTrabajadas;

    int i;
    int len;

    pArchivo = fopen(path,"w");

    if(pArchivo != NULL && pArrayListEmployee != NULL)
    {
        len = ll_len(pArrayListEmployee);

        fprintf(pArchivo,"%s,%s,%s,%s\n","id","nombre","horas","sueldo");

        for(i=0; i<len; i++)
        {
            unEmpleado = (Employee*)ll_get(pArrayListEmployee,i);
            employee_getId(unEmpleado,&id);
            employee_getNombre(unEmpleado,nombre);
            employee_getSueldo(unEmpleado,&sueldo);
            employee_getHorasTrabajadas(unEmpleado,&horasTrabajadas);
            fprintf(pArchivo,"%d,%s,%d,%d\n",id,nombre,horasTrabajadas,sueldo);
        }

        fclose(pArchivo);

        retorno = 1;
    }

    return retorno;
}

/** \brief Guarda los datos de los empleados en el archivo data.csv (modo binario).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee)
{
    int retorno = -1;

    FILE* pArchivo;
    Employee* unEmpleado;

    int len;
    int i;

    pArchivo = fopen(path,"wb");

    if(pArrayListEmployee != NULL && pArchivo != NULL)
    {
        len = ll_len(pArrayListEmployee);

        for(i=0; i<len; i++)
        {
            unEmpleado = (Employee*)ll_get(pArrayListEmployee,i);
            fwrite(unEmpleado,sizeof(Employee),1,pArchivo);
        }

        fclose(pArchivo);
        retorno = 1;
    }

    return retorno;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

void* controller_getEmpleadoPorId(LinkedList* pArrayListEmployee,int id)
{
    int i;
    int len;
    Employee* unEmpleado = NULL;

    len = ll_len(pArrayListEmployee);

    for(i=0; i<len; i++)
    {
        unEmpleado = (Employee*)ll_get(pArrayListEmployee,i);

        if(unEmpleado->id == id)
        {
            return unEmpleado;
            break;
        }
    }

    return unEmpleado;
}

/** \brief
 *
 * \param
 * \param
 * \return
 *
 */

int controller_getMaxID(LinkedList* pArrayListEmployee)
{
    int retorno = -1;

    int flag = 0;

    int len;
    int idMayor = 0;
    int i;

    Employee* unEmpleado;

    if(pArrayListEmployee != NULL)
    {
        len = ll_len(pArrayListEmployee);

        for(i=25;i<len;i++)
        {
            unEmpleado = (Employee*)ll_get(pArrayListEmployee,i);

            if(flag == 0 || unEmpleado->id > idMayor)
            {
                idMayor = unEmpleado->id;
                retorno = idMayor;
                flag = 1;
            }
        }
    }

    return retorno;
}
