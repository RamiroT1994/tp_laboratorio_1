/*
 * Input.h
 *
 *  Created on: 13 jun. 2020
 *      Author: admin
 */

#ifndef INPUT_H_
#define INPUT_H_

/** \brief Obtiene un caracter
 *
 * \param Cadena mensaje
 * \return caracter validado
 *
 */

char getChar(char[]);

/** \brief obtiene un entero
 *
 * \param Cadena mensaje
 * \return entero validado
 *
 */
int getInt(char[]);

/** \brief obtiene una cadena
 *
 * \param cadena mensaje
 * \param variable donde se guarda la cadena validada
 * \param cadena mensaje de error
 * \return void.
 *
 */
void getString(char[],char[], char[]);


#endif /* INPUT_H_ */
