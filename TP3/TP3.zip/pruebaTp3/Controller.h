/** \brief Carga una lista dinamica con datos de un archivo, en formato texto
 *
 * \param ruta del archivo
 * \param puntero a lista dinamica
 * \return -1 si puede cargar. 0 si abre archivo y carga. 1 si el puntero o lista son nulos. 2 lista ya cargada.
 *
 */
int controller_loadFromText(char* path , LinkedList* pArrayListEmployee);

/** \brief Carga una lista dinamica con datos de un archivo, en formato binario
 *
 * \param ruta del archivo
 * \param puntero a lista dinamica
 * \return -1 si puede cargar. 0 si abre archivo y carga. 1 el puntero o la lista son nulos. 2 lista ya cargada.
 *
 */
int controller_loadFromBinary(char* path , LinkedList* pArrayListEmployee);

/** \brief Carga un empleado en la lista dinamica
 *
 * \param puntero a la lista dinamica
 * \return -1 si no puede cargar. 0 carga empleado exitosa. 1 puntero a lista null. 2 carga cancelada por usuario.
 *
 */
int controller_addEmployee(LinkedList* pArrayListEmployee);

/** \brief modifica un empleado en la lista dinamica
 *
 * \param puntero a lista dinamica
 * \return -1 puntero a lista nulo. 0lista esta. 1 id empleado inexistente. 2 modificacion cargada. 3 carga cancelada.
 *
 */
int controller_editEmployee(LinkedList* pArrayListEmployee);

/** \brief Elimina un empleado
 *
 * \param puntero a lista dinamica
 * \return -1 no pudo eliminar empleado. 0 logro eliminar al empleado. 1 lista nula. 2 usuario cancela baja. 3 id empleado inexistente. 4 lista vacia
 *
 */
int controller_removeEmployee(LinkedList* pArrayListEmployee);

/** \brief lista los empleados
 *
 * \param puntero a lista dinamica
 * \return -1 lista nula. 0 listado correcto. 1 lista vacia.
 *
 */
int controller_ListEmployee(LinkedList* pArrayListEmployee);

/** \brief Establece diferentes criterios de ordenamiento
 *
 * \param puntero a lista dinamica
 * \return -1 lista no pudo ordenar. 0 ordenamiento exitoso. 1 lista nula. 2 lista vacia. 3 usuario cancelo el ordenamiento.
 *
 */
int controller_sortEmployee(LinkedList* pArrayListEmployee);

/** \brief Guarda cambios realizados en una lista en modo texto
 *
 * \param ruta de archivo
 * \param puntero a lista dinamica
 * \return -1 lista o el puntero al archivo  nulos. 0 guardado de datos exitoso.
 *
 */
int controller_saveAsText(char* path , LinkedList* pArrayListEmployee);

/** \brief Guarda cambios realizados en una lista en modo binario
 *
 * \param ruta de archivo
 * \param puntero a lista dinamica
 * \return -1 lista o puntero al archivo nulos. 0 guardado exitoso.
 *
 */
int controller_saveAsBinary(char* path , LinkedList* pArrayListEmployee);

/** \brief Obtiene el mayor id de la lista
 *
 * \param puntero a lista dinamica
 * \return -1 puntero a lista nulo. ID maximo encontrado.
 *
 */
int controller_getMaxID(LinkedList* pArrayListEmployee);

/** \brief Obtiene un empleado por su direccion ID
 *
 * \param puntero a lista dinamica
 * \param id a buscar
 * \return -1 si no encuentra empleado coincidente. Puntero a empleado.
 *
 */
void* controller_getEmpleadoPorId(LinkedList*,int);

