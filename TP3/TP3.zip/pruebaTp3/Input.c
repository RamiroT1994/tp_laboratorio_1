#include <string.h>
#include <stdio.h>
#include <conio.h>
#include "Input.h"

void getString(char mensaje[],char cadena[], char mensajeDeError[])
{
    char auxString[100];
    printf("%s",mensaje);
    fflush(stdin);
    gets(auxString);

    while(strlen(auxString)>50)
    {
        char auxString[100];
        printf(mensajeDeError,mensaje);
        fflush(stdin);
        gets(auxString);
    }

    strcpy(cadena,auxString);
}

int getInt(char mensaje[])
{
    int numero;
    printf("%s",mensaje);
    scanf("%d",&numero);

    return numero;
}

char getChar(char mensaje[])
{
    char caracter;
    printf("%s",mensaje);
    fflush(stdin);
    caracter = getch();


    return caracter;
}
